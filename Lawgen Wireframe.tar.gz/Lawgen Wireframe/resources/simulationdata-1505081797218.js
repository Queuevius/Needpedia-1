function initData() {
  jimData.variables["1"] = "";
  jimData.variables["The Human Body"] = "The Human Body";
  jimData.isInitialized = true;
}